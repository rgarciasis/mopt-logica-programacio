REPTE CAMPUS BYTE

No moguis cap fitxer ni canviïs l’estructura de carpetes.
Troba i repara cinc avaries:
- dues a index.html;
- dues a pagines/programa.html;
- una a contacte/contacte.html.

Comprova el recorregut:
inici -> programa -> contacte -> inici
i l’enllaç que porta directament a l’apartat Horaris.
